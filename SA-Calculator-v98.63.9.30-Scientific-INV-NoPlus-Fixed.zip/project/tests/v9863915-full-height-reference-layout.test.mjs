import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const css=fs.readFileSync('assets/css/app.css','utf8');
const html=fs.readFileSync('index.html','utf8');
test('active calculator stretches to the entire workspace before child percentages are applied',()=>{
 assert.match(css,/#app-container > #screen-viewport > #screen-calc\.active\s*\{[^}]*flex:1 1 100%!important/s);
 assert.match(css,/#app-container > #screen-viewport > #screen-calc\.active\s*\{[^}]*height:100%!important/s);
});
test('reference screenshot allocates 53 percent display and 47 percent keypad',()=>{
 assert.match(css,/#app-container > #screen-viewport > #screen-calc\.active > \.calc-display\s*\{[^}]*flex:0 0 53%!important/s);
 assert.match(css,/#app-container > #screen-viewport > #screen-calc\.active > \.main-keypad\s*\{[^}]*flex:0 0 47%!important/s);
});
test('keypad retains 19 keys, five rows and the double-width zero key',()=>{
 const keypad=html.match(/<div class="main-keypad"[\s\S]*?<\/div>/)?.[0]||'';
 assert.equal((keypad.match(/class="key-btn/g)||[]).length,19);
 assert.match(css,/grid-template-rows:repeat\(5,minmax\(0,1fr\)\)!important/);
 assert.match(css,/button\.key-btn\.zero-key\s*\{[^}]*grid-column:span 2!important/s);
});
test('calculator viewport and dock remain separate flex siblings',()=>{
 assert.match(css,/#app-container > #screen-viewport\s*\{[^}]*flex:1 1 0%!important/s);
 assert.match(css,/#app-container > #screen-viewport > #screen-calc\.active > \.main-keypad\s*\{[^}]*height:47%!important/s);
 assert.ok(html.includes('id="bottom-navigation"'));
});
