# Changelog — v98.63.9.30

## Video-based scientific keypad correction
- Removed the floating plus/More key and the additional-function overlay entirely.
- Replaced the removed final slot with cube root (`∛`), paired with cube (`x³`) through INV.
- INV now switches all applicable function pairs: `sin/asin`, `cos/acos`, `tan/atan`, `ln/eˣ`, `log/10ˣ`, `√/x²`, `∛/x³`, and `xʸ/x⁻ʸ`. Constant keys (`π`, `e`) and non-invertible functions (`|x|`, `x!`) remain unchanged.
- Scientific function labels are 20px baseline on compact viewports.
- Main numeric keypad surface is reduced by 20px when the scientific drawer is open; drawer geometry remains measured from the keypad.
- Added video-driven regression checks and numerical evaluation coverage for inverse pairs.
- Cache namespace and app version updated to `1.98.77-v98.63.9.30`; Android versionCode `1098078`.
