# Screenshot review — v98.63.6

## User-reported remaining defects

1. The currency picker still showed a keyboard/overlapping currency-text region at the top of the list.
2. A blank band remained below the five-tab Home / Tools / History / Favorite / Settings dock.

## Source-level findings

- The v98.63.5 dock rules reintroduced `env(safe-area-inset-bottom)` into both the dock's flex-basis/height and its padding. The earlier v98.63.4 correction explicitly noted that the Android WebView viewport in the supplied captures already ended above the Android system navigation area. Reserving the inset again therefore double-counted the bottom area.
- The currency picker used a dynamically created dialog. Its CSS had accumulated multiple competing rules for the panel, heading, option list, and option buttons. The final patch explicitly defines the panel as a three-row flex column (fixed heading, optional search, vertically scrolling options) and forces each currency option to be an independent full-width grid row.
- The currency keypad element was already hidden in older CSS, but `visibility:hidden` alone can retain layout space. The new layer explicitly sets the keypad to `display:none` and zero dimensions so it cannot reserve a phantom keyboard area.

## Changes

- Dock is a fixed 68 CSS-pixel row (58px on short viewports), with no Android bottom-safe-area reservation inside the web content. Android system navigation remains outside the WebView content viewport as in the supplied captures.
- Five navigation targets stretch to the dock's full content height.
- Currency picker has a clipped fixed header, a search row that stays hidden until the picker is open, and an independent vertical option list. Search input is not focused when the picker opens; the close button receives focus, so the Android IME does not open automatically.
- Currency keypad is removed from layout flow while preserving the existing amount editing logic and picker search interaction.
- The existing service-worker cache identity is retained to preserve the established release identity; the service worker uses network-first fetching for static assets when online, so the rebuilt consolidated stylesheet is fetched and cached on the next successful app load.

## Validation boundary

Source and automated regression checks can verify selectors, DOM structure, generated web bundle, workflow configuration, and ZIP integrity. Physical Vivo/Android WebView verification is not available in this environment; the final visual result must still be confirmed on-device.
