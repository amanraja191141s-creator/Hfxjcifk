# UI correction v98.63.9.10

- Home calculator display retains a 700px maximum width and a responsive dedicated display region.
- Home numeric/operator buttons are reduced to 64–66% sizing (zero key 70%) with touch-safe minimum height.
- Currency and unit option pickers now render only the currently selected option on open; alternative options are rendered only after the user enters a search query.
- Search is blurred/reset on picker open to prevent stale IME/query state from exposing the full catalogue.
- Hidden native selects and hidden duplicate labels are explicitly prevented from painting, even when legacy component display rules exist.
- Existing calculation, currency conversion, unit conversion, swap and selection event handlers are preserved.
- Service-worker cache namespace updated for this patch.

Automated verification: 378/378 Node tests passed; JavaScript syntax and Android web bundle build passed. Physical Android device/APK visual verification remains outstanding.
