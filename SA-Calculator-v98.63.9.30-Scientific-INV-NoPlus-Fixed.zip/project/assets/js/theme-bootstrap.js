/* v98.60 charcoal-violet theme bootstrap. */
(function bootstrapReferenceTheme() {
  const root = document.documentElement;
  root.style.setProperty('--sa-initial-accent', '#8b78ff');
  root.style.setProperty('--theme-accent', '#8b78ff');
  root.style.colorScheme = 'dark';
  root.setAttribute('data-theme', 'dark');
  root.setAttribute('data-theme-mode', 'dark');
})();
