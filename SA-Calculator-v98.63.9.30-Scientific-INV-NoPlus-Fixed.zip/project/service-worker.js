'use strict';
const CACHE='sa-calculator-v98-63-11-clean-runtime-v9863930-scientific-inverse-all-keys-no-more-20px';
// Production ships one canonical stylesheet; historical layers are retained only as test fixtures.
const ASSETS=['./','./index.html','./manifest.webmanifest','./assets/css/app.css','./assets/js/theme-bootstrap.js','./assets/js/localization.js','./assets/js/currency-localized-names.js','./assets/js/app.js','./assets/brand/sa-calculator-icon.png','./assets/brand/sa-calculator-192.png','./assets/brand/sa-calculator-512.png','./assets/brand/sa-calculator-home-logo.svg','./assets/brand/sa-home-neon-wave.svg'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(ASSETS)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>(key.startsWith('sumaire-')||key.startsWith('sa-calculator-'))&&key!==CACHE).map(key=>caches.delete(key)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
 const req=event.request;if(req.method!=='GET')return;
 const url=new URL(req.url);if(url.origin!==self.location.origin)return;
 // Never cache API responses: currency data must pass provider freshness validation on every refresh.
 if(url.pathname.startsWith('/api/'))return;
 const page=req.mode==='navigate'||req.destination==='document';
 event.respondWith((async()=>{
   const cache=await caches.open(CACHE);
   if(page){
     try{
       const fresh=await fetch(req);
       // A transient origin/server failure must not replace a working offline
       // app shell with a blank 5xx page. Keep real 4xx responses visible so
       // missing routes/assets are not disguised as successful app loads.
       if(fresh.status>=500){
         const cached=(await cache.match(req))||(await cache.match('./index.html'));
         if(cached)return cached;
       }
       if(fresh.ok)event.waitUntil(cache.put(req,fresh.clone()).catch(()=>{}));
       return fresh;
     }catch(_){return (await cache.match(req))||(await cache.match('./index.html'))||Response.error();}
   }
   try{const fresh=await fetch(req);if(fresh.ok&&/^(basic|default)$/.test(fresh.type))event.waitUntil(cache.put(req,fresh.clone()).catch(()=>{}));return fresh;}catch(_){return (await cache.match(req))||Response.error();}
 })());
});
